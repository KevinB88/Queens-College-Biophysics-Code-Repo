import func_calc_mfpt as calc
import numpy as np
import multiprocessing as mp
import filepaths as fp
import os
from datetime import datetime
import csv


def solve(w_param, N_param):
    rings = 32
    rays = 32
    d_c = 1
    radius = 1
    sim_time = 1
    v = -20
    ext_fact = 20

    mfpt = calc.solve(rings, rays, radius, d_c, sim_time, True, 1, w_param, w_param, v, N_param, True, ext_fact)
    print(f'Microtubule Configuration: {N_param}')
    print()
    return {f'W: {w_param}', f'MFPT: {mfpt}'}


def data_extraction(mfpt_container, file_path, file_name):

    current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    full_file_name = f'{file_name}_{current_time}.csv'

    full_path = os.path.join(file_path, full_file_name)

    rows = []
    for pair in mfpt_container:
        w_param = None
        mfpt = None
        for entry in pair:
            if entry.startswith('W: '):
                w_param = entry.split(': ')[1]
            elif entry.startswith('MFPT: '):
                mfpt = entry.split(': ')[1]
        rows.append([w_param, mfpt])

    with open(full_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['W', 'MFPT'])
        writer.writerow(rows)

    print(f'CSV file saved at: {full_path}, for time: {current_time}')


if __name__ == "__main__":

    # Important: Remember to edit the number of rings and rays from within the "solve" function (this feature will most likely be edited for convenience’s sake)

    N_list = [
        [0, 8, 16, 24]
    ]
    w_list = []

    # The lower and upper bounds are for calculating switch rates (w) at varying orders of magnitude
    lower_bound = -2
    upper_bound = 4
    for x in range(lower_bound, upper_bound):
        w_list.append(10**x)

    print(w_list)

    if len(w_list) > 6:
        process_count = 6
    else:
        process_count = len(w_list)

    for n in range(len(N_list)):

        with mp.Pool(processes=process_count) as pool:
            mfpt_results = pool.mp(solve, w_list, N_list[n])
        print(mfpt_results)
        data_extraction(mfpt_results, fp.mfpt_data_fp, f'MFPT_Results_N={len(N_list[n])}-')


'''
    Common Microtubule configurations

    [0, 8, 16, 24]
    [0, 4, 8, 12, 16, 20, 24, 28]
    [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30]
    
    Loop for microtubule configurations
'''

