
mfpt_data_fp = "N:\\Queens College 2024\\Research\\Theoretical-Biophysics\\Fall-Semester\\Version-F1.0\\Python\\MFPT-exclusive\\data-output"
