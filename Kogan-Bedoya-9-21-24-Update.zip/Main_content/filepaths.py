

# base_mass_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/mass/base'
# base_mass_plt_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/mass/base/plot'
#
# mass_loss_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Fall-Software/algo-version-9.1/output/MFPT-related/Current-mass-loss'
# mass_loss_plt_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/mass/loss/plot'
#
# phi_ang_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/phi/angular'
# phi_ang_plt_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/phi/angular/plot'
#
# phi_cent_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/phi/central'
# phi_cent_plt_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/phi/central/plot'
#
# phi_rad_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/phi/radial'
# phi_rad_plt_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Fall-Software/algo-version-9.1/output/DL/phi_rad'
#
# rho_rad_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/rho/radial'
# rho_raf_plt = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/rho/radial/plot'
#
# mfpt_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/mfpt'
# mfpt_plt_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/mfpt/plots'
#
# ani_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Algorithm-Version-F1.0-VIII/csv_output/Python/animation'
#
# graph_fp = '/Users/kbedoya88/Desktop/PROJECTS24/PyCharm/Theoretical-Biophysics/Bedoya-Kogan-Algorithm-Python/Version-F1.0-9/graphic'
#
# generic_fp = 'N:\\Queens College 2024\\Research\\Theoretical-Biophysics\\Fall-Semester\\Queens-College-Biophysics-Code-Repo-Main_content\\Version-F1.0-9.2\\output'

data_generic_fp = "N:\\Queens College 2024\\Research\\Theoretical-Biophysics\\Fall-Semester\\Version-F1.0\\Python\\Main_content\\data"
