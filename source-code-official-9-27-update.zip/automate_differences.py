import pandas as pd
from datetime import datetime
import os

def calculate_diff(csv_file_1, csv_file_2, file_name, file_path, method):
    df_1 = pd.read_csv(csv_file_1)
    df_2 = pd.read_csv(csv_file_2)

    MFPT_diff = []

    for val_1, val_2 in zip(df_1['MFPT'], df_2['MFPT']):
        MFPT_diff.append(val_1 - val_2)
    print(MFPT_diff)

    df = pd.DataFrame({
        'W' : df_1['W'],
        'MFPT (ext)' : df_1['MFPT'],
        f'MFPT {method}' : df_2['MFPT'],
        'Difference' : MFPT_diff
    })

    current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    full_file_name = f'{file_name}_{current_time}.csv'

    if not os.path.exists(file_path):
        os.makedirs(file_path)

    df.to_csv(os.path.join(file_path, full_file_name), sep=',', index=False)


if __name__ == "__main__":
    destination_path = "/Users/olegkogan/Desktop/Fall-Semester-24/Biophysics-PDE-Solver-Fall-24/BP-KB-2024-Project/Version-F1.0/MFPT-exclusive/data-output/General"

    method = "0_1"

    filename = f"v=-10_N=16_num_diff_ext_v_md_{method}_report_"

    MFPT_ext = "/Users/olegkogan/Desktop/Fall-Semester-24/Biophysics-PDE-Solver-Fall-24/BP-KB-2024-Project/Version-F1.0/MFPT-exclusive/data-output/2024-09-22_14-21-33-ext-method/MFPT_Results_N=16_v=-10__2024-09-23_10-48-07.csv"
    MFPT_md_0_1 = "/Users/olegkogan/Desktop/Fall-Semester-24/Biophysics-PDE-Solver-Fall-24/BP-KB-2024-Project/Version-F1.0/MFPT-exclusive/data-output/2024-09-25_08-45-18-dm-0_1/MFPT_Results_N=16_v=-10__2024-09-25_23-59-30.csv"
    MFPT_md_0_0_1 = "/Users/olegkogan/Desktop/Fall-Semester-24/Biophysics-PDE-Solver-Fall-24/BP-KB-2024-Project/Version-F1.0/MFPT-exclusive/data-output/2024-09-26_03-23-24-dm-0_0_1/MFPT_Results_N=16_v=-10__2024-09-27_01-59-05.csv"

    calculate_diff(MFPT_ext, MFPT_md_0_1, filename, destination_path, method)