
mfpt_data_fp = '/Users/olegkogan/Desktop/Fall-Semester-24/Biophysics-PDE-Solver-Fall-24/BP-KB-2024-Project/Version-F1.0/MFPT-exclusive/data-output'
