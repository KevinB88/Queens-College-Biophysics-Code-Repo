
import func_calc_mfpt as calc
import func_tab as tb
import func_plots as plt

import multiprocessing as mp
import filepaths as fp
from datetime import datetime
from functools import partial
import time


def solve(N_param, rg_param, ry_param, v_param, ext_param, w_param):
    M = rg_param
    N = ry_param
    d_c = 1
    radius = 1
    sim_time = 1
    v = v_param
    ext_fact = ext_param

    mfpt = calc.solve_mass_decay(M, N, radius, d_c, sim_time, True, 1, w_param, w_param, v, N_param, True, ext_fact)
    print(f'Microtubule Configuration: {N_param}')
    print()
    return {f'W: {w_param}', f'MFPT: {mfpt}'}


def parallel_process(rg_param, ry_param, v_param, ext_param, N_list, w_low_bound, w_high_bound):
    w_list = []
    lower_bound = w_low_bound
    upper_bound = w_high_bound
    for x in range(lower_bound, upper_bound+1):
        w_list.append(10 ** x)

    print(w_list)

    if len(w_list) > 8:
        process_count = 8
    else:
        process_count = len(w_list)

    current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    data_filepath = tb.create_directory(fp.mfpt_data_fp, current_time)

    for n in range(len(N_list)):
        with mp.Pool(processes=process_count) as pool:
            mfpt_results = pool.map(partial(solve, N_list[n], rg_param, ry_param, v_param, ext_param), w_list)
        print(mfpt_results)

        tb.data_extraction_pandas(mfpt_results, data_filepath, f'MFPT_Results_N={len(N_list[n])}_v={velocity}_')
        time.sleep(1)

    plt.plot_all_csv_in_directory(data_filepath, N_list, data_filepath, f'MFPT_versus_W_v={velocity}_', True)


if __name__ == "__main__":

    rings = 16
    rays = 16
    velocity = -10
    extension_factor = 25

    microtubule_configs = [
        [0, 4, 8, 12],
        [0, 2, 4, 6, 8, 10, 12, 14],
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    ]

    # temp_path = '/Users/olegkogan/Desktop/Fall-Semester-24/Biophysics-PDE-Solver-Fall-24/BP-KB-2024-Project/Version-F1.0/MFPT-exclusive/data-output/General'
    #
    # file_1_ext = '/Version-F1.0/MFPT-exclusive/data-output/2024-09-22_14-21-33-ext-method/MFPT_Results_N=4_v=-10__2024-09-22_19-05-44.csv'
    # file_2_ext = '/Version-F1.0/MFPT-exclusive/data-output/2024-09-22_14-21-33-ext-method/MFPT_Results_N=8_v=-10__2024-09-23_01-08-05.csv'
    # file_3_ext = '/Version-F1.0/MFPT-exclusive/data-output/2024-09-22_14-21-33-ext-method/MFPT_Results_N=16_v=-10__2024-09-23_10-48-07.csv'

    # file_1_md_0_1 = '/Users/olegkogan/Desktop/Fall-Semester-24/Biophysics-PDE-Solver-Fall-24/BP-KB-2024-Project/Version-F1.0/MFPT-exclusive/data-output/2024-09-25_08-45-18-dm-0_1/MFPT_Results_N=4_v=-10__2024-09-25_10-39-53.csv'
    # file_2_md_0_1 = '/Users/olegkogan/Desktop/Fall-Semester-24/Biophysics-PDE-Solver-Fall-24/BP-KB-2024-Project/Version-F1.0/MFPT-exclusive/data-output/2024-09-25_08-45-18-dm-0_1/MFPT_Results_N=8_v=-10__2024-09-25_13-51-15.csv'
    # file_3_md_0_1 = '/Users/olegkogan/Desktop/Fall-Semester-24/Biophysics-PDE-Solver-Fall-24/BP-KB-2024-Project/Version-F1.0/MFPT-exclusive/data-output/2024-09-25_08-45-18-dm-0_1/MFPT_Results_N=16_v=-10__2024-09-25_23-59-30.csv'

    # file_1_md_0_0_1 = "/Version-F1.0/MFPT-exclusive/data-output/2024-09-26_03-23-24-dm-0_0_1/MFPT_Results_N=4_v=-10__2024-09-26_06-12-10.csv"
    # file_2_md_0_0_1 = "/Version-F1.0/MFPT-exclusive/data-output/2024-09-26_03-23-24-dm-0_0_1/MFPT_Results_N=8_v=-10__2024-09-26_10-59-01.csv"
    # file_3_md_0_0_1 = "/Version-F1.0/MFPT-exclusive/data-output/2024-09-26_03-23-24-dm-0_0_1/MFPT_Results_N=16_v=-10__2024-09-27_01-59-05.csv"

   # # microtubule_configs = [
    # #     [1],
    # #     [1, 0],
    # #     [0, 1, 2],
    # #     [0, 1, 2, 3]
    # # ]

    # plt.plot_all_csv_in_directory_manual([file_1_ext, file_2_ext, file_3_ext, file_1_md_0_0_1, file_2_md_0_0_1, file_3_md_0_0_1], ['4_ext', '8_ext', '16_ext', '4_md_0.001', '8_md_0.001', '16_md_0.001'], temp_path, f'MFPT_versus_W_v={velocity}_', True, custom_label=True)

    # plt.plot_all_csv_in_directory_manual([file_1_ext, file_2_ext, file_3_ext, file_1_md_0_1, file_2_md_0_1, file_3_md_0_1], ['4_ext', '8_ext', '16_ext', '4_md_0.1', '8_md_0.01', '16_md_0.01'], temp_path, f'MFPT_versus_W_v={velocity}_', True, custom_label=True)

    w_low = -2
    w_high = 4

    parallel_process(rings, rays, velocity, extension_factor, microtubule_configs, w_low, w_high)

'''
    Common Microtubule configurations

    [0, 8, 16, 24]
    [0, 4, 8, 12, 16, 20, 24, 28]
    [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30]
'''


